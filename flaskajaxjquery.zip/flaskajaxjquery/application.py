import os
import datetime
import re
from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session, url_for, current_app
from flask_session import Session
from tempfile import gettempdir
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError



app = Flask(__name__)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///final.db")     #global variable, database connectivity chain, variable available for all the program

@app.route('/')
def index():
	return render_template('form.html')

@app.route('/process', methods=['POST'])  #define route for display page web
def process():

	email = request.form['email']         # retrieve datas sent through ajax
	name = request.form['name']           # retrieve datas sent through ajax
	adress = request.form['adress']       # retrieve datas sent through ajax
	city = request.form['city']           # retrieve datas sent through ajax
	#state = request.form.get("state")
	state = request.form['state']         # retrieve datas sent through ajax
	phone = request.form['phone']         # retrieve datas sent through ajax
	typeb = request.form['typec']         # retrieve datas sent through ajax
	my_str = name
	my_new_string = re.sub('[^a-zA-Z0-9 \n\.]','', my_str)   #to format the string and insert only values we will work with in the database
	site = my_new_string.replace(" ","")
	pageweb = site+".html"                # format of page to insert in the database
    # to be sure those fields get some values
	if not adress or not email or not name or not city or not typeb or not state :
		return jsonify({'error' : 'Missing data!'})
	else:
		#newName = "Success"
		#newName = phone #[::-1]  parameter to reverse the name
		newName = state #[::-1]  parameter to reverse the name
		#newName = request.form.get("state")
		user = db.execute("SELECT * FROM user")
		nbre = len(user)
		if nbre < 1 :
		  return jsonify({'name' : nbre})
		else:
		  newName = "Success"
		  insert=db.execute("INSERT INTO user(name,street,city,state,phone,email,activity,website) VALUES (:name, :adress, :city, :state, :phone, :email, :typeb, :siteweb)",
		  name=name, adress=adress, city=city, state=state, phone=phone,email=email,typeb=typeb,siteweb=pageweb)
		  return jsonify({'name' : newName})

   #return jsonify({'error' : 'Missing data!'})


if __name__ == '__main__':
	app.run(debug=True)

@app.route("/", methods=["GET"])
def get_index():
    return redirect("/form")


@app.route("/form", methods=["GET"])
def get_form():
    return render_template("form.html")

@app.route("/yellowpage")
def yellowpage():
	#here we will display all informations of the user table
    users = db.execute("SELECT * FROM user")
    #we send datas to the html file to display
    return render_template("yellowpage.html", users=users)
     # manage request context

#with app.test_request_context('/'):    use by importing request, current_app

@app.route("/EvelynHairBraiding", methods=["GET"])
def hair():
	return render_template("EvelynHairBraiding.html")
@app.route("/Policememphis", methods=["GET"])
def police():
	#email = request.form['email']         # retrieve datas sent through ajax
	#name = request.form['name']           # retrieve datas sent through ajax
	#adress = request.form['adress']       # retrieve datas sent through ajax
	#city = request.form['city']           # retrieve datas sent through ajax
	#state = request.form.get("state")
	#state = request.form['state']         # retrieve datas sent through ajax
	#phone = request.form['phone']         # retrieve datas sent through ajax
	#typeb = request.form['typec']         # retrieve datas sent through ajax
	#if not email or not name :
	#	return jsonify({'error' : 'Missing data!'})
	#else:
		return render_template("policememphis.html")
@app.route("/Baptisthospital", methods=["GET"])
def hospital():
	return render_template("Baptisthospital.html")
@app.route("/Methodisthospital", methods=["GET"])
def hospitalm():
	return render_template("Methodisthospital.html")
@app.route("/Flowerstore", methods=["GET"])
def flower():
	return render_template("Flowerstore.html")
@app.route("/Patrick", methods=["GET"])
def design():
	return render_template("Pmotsebo_web.developer.pdf")










