$(document).ready(function() {

/**	$('form').on('submit', function(event) {

		$.ajax({
			data : {
				name : $('#nameInput').val(),
				email : $('#emailInput').val(),
				adress : $('#adressInput').val(),
				city : $('#cityInput').val(),
				//state : + $('#stateinput').val()
				state : $("#stateinput option:selected").val(),
				//keyname:$('#AttorneyEmpresa option:selected').val()
				phone : $('#phoneInput').val(),
				typec : $('#typeinput option:selected').val()
			},
			type : 'POST',
			url : '/process'
		})
		.done(function(data) {

			if (data.error) {
				$('#errorAlert').text(data.error).show();
				$('#successAlert').hide();
			//	console.log(name, email);
			}
			else {
				var recup = $('#stateinput').val();
				$('#successAlert').text(data.name).show();
				$('#errorAlert').hide();
				//console.log(name, email);
				alert("Data saved successfully");
				//alert("Value: " + $("#stateinput option:selected").val());
			}

		});

		event.preventDefault();

	});   **///fin first submit
$('form').on('submit', function(event) {

		$.ajax({
			data : {

			},
			type : 'GET',
			url : '/EvelynHairBraiding'
		})
		.done(function(data) {

			if (data.error) {

			}
			else {

				alert("Our Beauty shop is Thanking you for your order");
			}

		});

		event.preventDefault();

	});



});  // fin document ready
