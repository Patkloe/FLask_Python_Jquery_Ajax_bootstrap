import re
my_str = "hey th~!ere"
my_new_string = re.sub('[^a-zA-Z0-9 \n\.]','', my_str)
affiche = my_new_string.replace(" ","")
print(affiche)
